package com.example.demo.database;

import java.sql.ResultSet;
import java.sql.SQLException;

public class testdb {


    public static void  main(String[] args) throws SQLException {
       test();
    }
    public static void test() throws SQLException {
        DB db = new DB();
        String sql = "select * from answer";
        ResultSet rs = db.executeQuery(sql);
        while (rs.next()) {
            try {

                String a = rs.getString(2);
                System.out.println(a);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }
}
