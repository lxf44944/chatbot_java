package com.example.demo.model;

public interface Model {
  String getString();
}
