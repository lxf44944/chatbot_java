package com.example.demo.tuling;

import java.io.IOException;

public class JuHeChatUtil {
    public static void main(String[] args) throws IOException {
        test_tuling test_tuling = new test_tuling("你好");
        System.out.println(test_tuling.GetAnswer());
    }
}
