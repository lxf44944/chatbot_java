package com.example.demo;

import com.example.demo.pojo.Content;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.List;

@Component
public class HtmlParseUtil {
    public static void main(String[] args) throws IOException {
            new HtmlParseUtil().parseJD("编程").forEach(System.out::println);
    }
    public List<Content> parseJD(String keywords) throws IOException {
        //获取请求      https://search.jd.com/Search?keyword=java
        //要联网，不能获取ajax
        String url = "https://search.jd.com/Search?keyword="+keywords;
        //解析网页(返回的document就是js页面)
        Document document = Jsoup.parse(new URL(url), 30000);
        //所有在js中可以用的这里都可以用
        Element element = document.getElementById("J_goodsList");
        //System.out.println(element.html());
        //获取所有li元素
        Elements elements = element.getElementsByTag("li");

        ArrayList<Content> goodlists = new ArrayList<>();
        //获取元素中的内容
        for(Element el : elements){
            //图片延迟加载
            String img = el.getElementsByTag("img").eq(0).attr("data-lazy-img");
            String price = el.getElementsByClass("p-price").eq(0).text();
            String title = el.getElementsByClass("p-name").eq(0).text();
            Content content = new Content();
            content.setImg(img);
            content.setTitle(title);
            content.setPrice(price);
            goodlists.add(content);
           /* System.out.println("***********************");
            System.out.println(img);
            System.out.println(price);
            System.out.println(title);*/
        }
        return goodlists;
    }
}
