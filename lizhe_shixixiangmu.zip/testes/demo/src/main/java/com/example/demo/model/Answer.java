package com.example.demo.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import javax.persistence.*;

@Data
@NoArgsConstructor

public class Answer implements Model {
  private int id;
  private String answerText;
  private int votes;
  private int question_id;

  public Answer(int id, String answerText, int votes, int question_id) {
    this.id = id;
    this.answerText = answerText;
    this.votes = votes;
    this.question_id = question_id;
  }

  @Override
  public String getString() {
    return answerText;
  }

  public int getVotes() {
    return votes;
  }

  public void setVotes(int votes) {
    this.votes = votes;
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getAnswerText() {
    return answerText;
  }

  public void setAnswerText(String answerText) {
    this.answerText = answerText;
  }

  public int getQuestion() {
    return question_id;
  }

  public void setQuestion(int question_id) {
    this.question_id = question_id;
  }
}
