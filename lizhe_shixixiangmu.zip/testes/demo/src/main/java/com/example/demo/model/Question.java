package com.example.demo.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;


@Data


public class Question implements Model {

  private int id;
 // private List<Answer> answers;
  private String questionText;
  private int votes;
  private Date pubDate;

  public Question(int id, String questionText, int votes) {
    this.id = id;
    this.questionText = questionText;
    this.votes = votes;
  }

  public int getVotes() {
    return votes;
  }

  public void setVotes(int votes) {
    this.votes = votes;
  }

  @Override
  public String getString() {
    return questionText;
  }

  public boolean wasPublishedRecently() {
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(new Date());
    calendar.add(Calendar.DATE, -1);
    return pubDate.compareTo(calendar.getTime()) <= 1;
  }

 /* public Answer getBestAnswer() {
    answers.sort(Comparator.comparingInt(Answer::getVotes));
    return answers.get(answers.size() - 1);
  }*/

  /*public List<Answer> getAnswers() {
    return answers;
  }

  public void setAnswers(List<Answer> answers) {
    this.answers = answers;
  }*/

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public void setQuestionText(String questionText) {
    this.questionText = questionText;
  }

  public Date getPubDate() {
    return pubDate;
  }

  public void setPubDate(Date pubDate) {
    this.pubDate = pubDate;
  }
}
