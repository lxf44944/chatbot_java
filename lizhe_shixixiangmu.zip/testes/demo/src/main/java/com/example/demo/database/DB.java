package com.example.demo.database;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DB {
    private String classname="com.mysql.jdbc.Driver";	//数据库驱动类路径
    private String url="jdbc:mysql://localhost:3306/good?useUnicode=true&characterEncoding=UTF-8"; //数据库URL
    private String url2="jdbc:mysql://139.196.220.1/class2?useUnicode=true&characterEncoding=utf-8"; //数据库URL

    private String user="root";	//登录数据库的用户名
    private String pwd="123456";	//登录数据库的密码
    private String user2="root";	//登录数据库的用户名
    private String pwd2="root";	//登录数据库的密码

    private Connection conn=null;	//申明一个Connection对象
    private Statement stmt=null; //声明一个Statement对象
    private ResultSet rs=null;

    /*通过构造方法加载数据库驱动*/
    public DB(){	//DB类的构造方法
        try{	//必须使用try catch语句捕获加载数据库驱动时可能发生的异常
            Class.forName(classname).newInstance();	//加载数据库驱动
        }catch (Exception e){
            e.printStackTrace();	//输出异常信息
            System.out.println("加载数据库驱动失败！！");
        }
    }
    /*创建数据库连接*/
    public Connection createConn(){
        try{
            conn=DriverManager.getConnection(url, user, pwd);
        }catch(SQLException e){
            e.printStackTrace();
            System.out.println("获取数据库连接失败！！");
        }
        return conn;
    }

    /*获取Statement对象*/
    public Statement getStmt(){
        createConn();
        try{
            //调用Connection类实例的createStatement()方法创建一个Statement类对象
            stmt=conn.createStatement();
        }catch(SQLException e){
            e.printStackTrace();
            System.out.println("创建Statement对象失败！！");
        }
        return stmt;
    }

    /*创建对数据库进行操作的增加、删除和修改的executeUpdate()方法*/
    public boolean executeUpdate(String sql){
        boolean mark=false;
        try{
            getStmt();	//创建一个Statement对象
            int iCount=stmt.executeUpdate(sql);	//执行操作，并获取所影响的记录数
            if(iCount>0)	//更新数据库成功
                mark=true;
            else			//更新失败
                mark=false;
        }catch(SQLException e){
            e.printStackTrace();
        }
        return mark;
    }

    /*查询数据库*/
    public ResultSet executeQuery(String sql){

        try{
            getStmt();
            try{
                rs=stmt.executeQuery(sql);
            }catch(Exception e){
                e.printStackTrace();
                System.out.println("查询数据库失败！！");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return rs;
    }
    public void close(){
        try{if(rs!=null)rs.close();}catch(Exception e){}
        try {stmt.close();}catch(Exception e){}
        try {conn.close();}catch(Exception e){}
    }
}
