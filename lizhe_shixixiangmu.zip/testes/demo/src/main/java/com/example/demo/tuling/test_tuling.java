package com.example.demo.tuling;


import com.example.demo.model.Question;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class test_tuling {
    public String questions;
    public test_tuling(String questions){
        this.questions = questions;
    }

    public String GetAnswer()throws IOException{
        String APIKEY = "c456994e9b6fe34666da7667ee860aae";
        String INFO = URLEncoder.encode(this.questions, "utf-8");
        String getURL ="http://www.tuling123.com/openapi/api?key="+APIKEY+"&info="+INFO;
        URL getUrl = new URL(getURL);
        HttpURLConnection connection = (HttpURLConnection)getUrl.openConnection();
        connection.connect();

        // 取得输入流，并使用Reader读取
        BufferedReader reader = new BufferedReader(new InputStreamReader( connection.getInputStream(), "utf-8"));
        StringBuffer sb = new StringBuffer();
        String line = "";
        while ((line = reader.readLine()) != null){
            sb.append(line);
        }
        reader.close();
        // 断开连接
        connection.disconnect();

        return getChinese(sb.toString());
    }
    public static String getChinese(String paramValue) {
        String regex = "([\u4e00-\u9fa5]+)";
        String str = "";
        Matcher matcher = Pattern.compile(regex).matcher(paramValue);
        while (matcher.find()) {
            str+= matcher.group(0);
        }
        return str;
    }


}

