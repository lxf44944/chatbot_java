package com.example.demo.config;

import com.alibaba.fastjson.JSON;
import com.example.demo.HtmlParseUtil;
import com.example.demo.database.DB;
import com.example.demo.model.Answer;
import com.example.demo.pojo.Content;
import com.example.demo.tuling.test_tuling;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Component
//业务编写
public class ContentService {
    @Autowired
    private RestHighLevelClient restHighLevelClient;
//需要
    public static void main(String[] args) throws IOException {
        new ContentService().parseContent("java");
    }
    //解析数据放入ES中
    public boolean parseContent(String keywords) throws IOException {
        List<Content> contents = new HtmlParseUtil().parseJD(keywords);
        //把查询的数据放入ES中
        BulkRequest bulkRequest = new BulkRequest();
        bulkRequest.timeout("2m");
        for (int i = 0; i<contents.size();i++){
            bulkRequest.add(
                    new IndexRequest("jd_list")
                            .id(""+(i+1))//没写id会生成随机id
                            .source(JSON.toJSONString(contents.get(i)), XContentType.JSON)
            );
        }
        BulkResponse bulkResponse = restHighLevelClient.bulk(bulkRequest, RequestOptions.DEFAULT);
      //  System.out.println(bulkResponse.hasFailures());//是否失败，返回false代表成功
        return !bulkResponse.hasFailures();
    }
    //2.获取数据进行搜索
    public String searchPage(String keyword, int pageNo, int pageSize) throws IOException, SQLException {
        if (pageNo <= 0) {
            pageNo = 0;
        }
        //条件搜索
        // SearchRequest searchRequest  = new SearchRequest("jd_list");
        SearchRequest searchRequest = new SearchRequest("test_log");
//        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();

        //分页
//        sourceBuilder.from(pageNo);
//        sourceBuilder.size(pageSize);

        //精确匹配
        /*MatchQueryBuilder termQueryBuilder = QueryBuilders.matchQuery("title",keyword);
        sourceBuilder.query(termQueryBuilder);
        sourceBuilder.timeout(new TimeValue(60, TimeUnit.SECONDS));*/

        SearchSourceBuilder sourceBuilder2 = new SearchSourceBuilder();
        sourceBuilder2.from(pageNo);
        sourceBuilder2.size(pageSize);
        sourceBuilder2.query(QueryBuilders.matchQuery("question_text", keyword));//如我我们需要查询的title中有“大话西游电影”，“大话西游小说”，使用prefixQuery查询“大话西游”，那么那两条数据就会出来
        sourceBuilder2.timeout(new TimeValue(60, TimeUnit.SECONDS));

//        SearchSourceBuilder sourceBuilder3 = new SearchSourceBuilder();
//        sourceBuilder3.query(QueryBuilders.matchAllQuery());

        System.err.println(sourceBuilder2.toString());

        //执行搜索
        searchRequest.source(sourceBuilder2);
        SearchResponse searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
        //解析结果
        ArrayList< String> list = new ArrayList<>();
        ArrayList<Answer> list2 = new ArrayList<>();
        int i =0;
        for (SearchHit documentFields : searchResponse.getHits().getHits()) {
          //  System.out.println(documentFields.getId());
            DB db = new DB();

            String sql = "Select * from answer where question_id = "+documentFields.getId();
           // System.out.println(sql);
            ResultSet rs = db.executeQuery(sql);
            while (rs.next()) {
                try {
                    String a = rs.getString(2);
                    //System.out.println(a);
                    Answer answer = new Answer(rs.getInt(1),
                                               rs.getString(2),
                                               rs.getInt(3),
                                               rs.getInt(4)
                    );
               //     System.out.println(answer.getVotes()+"wwww");
               //     list.add(a);
                    list2.add(answer);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
            //list.add(documentFields.getSourceAsMap());
        }
    /*  if(list.size()==0){
          test_tuling test_tuling = new test_tuling(keyword);
          String text =  test_tuling.GetAnswer();
          Answer answer = new Answer(0,
                                      text,
                                    0,
                                     0);
        list.add(text);
      }*/
        ArrayList<String> arrayList = getAnswerText(list2,keyword);
        System.out.println(list2.size());
        return arrayList.get(0);
    }
    public ArrayList<String> getAnswerText(ArrayList<Answer> arrayList,String keyword) throws IOException, SQLException {
        int maxvote = 0;
        int id = 0;
        ArrayList< String> list = new ArrayList<>();
        for (int i = 0;i<arrayList.size();i++){
            if(maxvote<=arrayList.get(i).getVotes()){
                maxvote = arrayList.get(i).getVotes() ;
                id = arrayList.get(i).getId();
            }
            if(maxvote>arrayList.get(i).getVotes()){
                maxvote = maxvote;
            }
        }
        System.out.println(maxvote);
        if(maxvote<=2){
            test_tuling test_tuling = new test_tuling(keyword);
            String text =  test_tuling.GetAnswer();
            list.add(text);
        }
        if(maxvote>2){
            DB db = new DB();
            String sql = "Select * from answer where id = "+id;
            System.out.println(sql);
            ResultSet rs = db.executeQuery(sql);
            while (rs.next()) {
                try {
                    String a = rs.getString(2);
                    list.add(a);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        }
        return list;
    }
}
